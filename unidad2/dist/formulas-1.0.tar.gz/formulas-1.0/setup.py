from setuptools import setup

setup(
    name='formulas',
    version='1.0',
    description='The equations example Application Programming',
    author='KCA',
    author_email='kevinca740@gmail.com',
    url='trello.com/pa',
    py_modules=['formulas'],
)
