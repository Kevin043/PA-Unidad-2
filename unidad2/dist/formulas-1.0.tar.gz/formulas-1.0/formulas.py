def carga_electrica(i:float, t:float) -> float:
    z = i * t
    return z


def aceleracion_angular(t:float) -> float:
    a = t ** -2
    return a